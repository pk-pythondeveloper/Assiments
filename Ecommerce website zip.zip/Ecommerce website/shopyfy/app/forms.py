from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm,UsernameField,PasswordResetForm
from django.contrib.auth.models import User
from django.utils.translation import gettext, gettext_lazy as _
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import password_validation
from .models import customer
class Customer_regitation(UserCreationForm):
    username=forms.CharField(label='username', widget=forms.TextInput(attrs={'class':'form-control'}))
    password1=forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2=forms.CharField(label='confirm Password (again)', widget=forms.PasswordInput(attrs={'class':'form-control'}))
    email=forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class':'form-control'}))
    class Meta:
        model = User
        fields =['username','email','password1','password2']
        labels={'email':'Email'}
        widgets={'username':forms.TextInput(attrs={'class':'forms-control'})}

class LoginForm(AuthenticationForm):
    username= UsernameField(label='username', widget=forms.TextInput(attrs={'class':'form-control','autofocus':True}))
    password= forms.CharField(label='Password',strip=False, widget=forms.PasswordInput(attrs={'class':'form-control','autofocus':True,'autocomplete':'current-password'}))

class changepassword(PasswordChangeForm):
    old_password=forms.CharField(label='old password', strip=False, widget=forms.PasswordInput(attrs={'autocomplete':'current-password', 'autofocos':True, 'class':'form-control'}))
    new_password1=forms.CharField(label='New password', strip=False, widget=forms.PasswordInput(attrs={'autocomplete':'new-password','autofocus':True, 'class':'form-control',}),help_text=password_validation.password_validators_help_text_html())
    new_password2=forms.CharField(label='confirm new password', strip=False, widget=forms.PasswordInput(attrs={'autocomplete':'new-password','autofocus':True,'class':'form-control'}))

class passwordressetform(PasswordResetForm):
    email=forms.EmailField(label='email', max_length=50, widget=forms.EmailInput(attrs={'class':'form-control','autocomplite':'email'}))
    
class costumerprofileform(forms.ModelForm):
    class Meta:
        model = customer
        fields ={'name','locality','city','state','zipcode'}
        widgets={'name':forms.TextInput(attrs={'class':'form-control'}),'locality':forms.TextInput(attrs={'class':'form-control'}),'city':forms.TextInput(attrs={'class':'form-control'}),'zipcode':forms.NumberInput(attrs={'class':'form-control'})}