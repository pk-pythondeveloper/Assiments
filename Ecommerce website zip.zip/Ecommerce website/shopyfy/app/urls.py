from django.urls import path
from django import urls
from app import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from .forms import LoginForm,changepassword,passwordressetform
urlpatterns = [
    # path('', views.home), 
    path('',views.Productview.as_view(),name='home'),
    path('product_detail/<int:pk>', views.product_detail.as_view(), name='product_detail'),
    path('add_to_cart/', views.add_to_cart, name='add-to-cart'),
    path('cart/',views.show_cart,name='show-cart'),
    path('pluscart/',views.pluscart,),
    path('minuscart/',views.minuscart,),
    path('removecart/',views.removecart,),
    path('buy/', views.buy_now, name='buy-now'),
    path('profile/', views.costomerprofile.as_view(), name='profile'),
    path('address/', views.address, name='address'),
    path('orders/', views.orders, name='orders'),
    path('changepassword/', auth_views.PasswordChangeView.as_view(template_name='app/changepassword.html', form_class=changepassword,success_url='/passwordchanged/'),name='changepassword'),
    path('passwordchanged/',auth_views.PasswordChangeView.as_view(template_name='app/passwordchanged.html'),name='passwordchanged'),
    path('forgetpassword/',auth_views.PasswordResetView.as_view(template_name='app/forgetpassword.html',form_class=passwordressetform, success_url='/passwordreset/'),name='forgetpassword'),
    path('password-reset/done/',auth_views.PasswordResetDoneView.as_view(template_name='app/resetpassword.html'),name='passwordresetdone'),
    # path('passwordreset/',auth_views.PasswordResetConfirmView.as_view(template_name='app/resetpassword.html'),name='resetpassword'),
    path('mobile/<slug:data>', views.mobile, name='mobiledata'),
    path('mobile/', views.mobile, name='mobile'),
    path('accounts/login/',auth_views.LoginView.as_view(template_name='app/login.html', authentication_form=LoginForm), name='login'),
    # path('logout/',auth_views.LogoutView.as_view(next_page='login'),name='logout'),
    path('logout/',views.logout_user,name='logout'),
    path('registration/', views.customerregistration.as_view(), name='customerregistration'),
    path('checkout/', views.checkout, name='checkout'),
    
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
