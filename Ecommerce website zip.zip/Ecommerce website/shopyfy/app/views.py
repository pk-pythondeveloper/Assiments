from django.shortcuts import render,HttpResponseRedirect,redirect
from django.views import View
from .forms import Customer_regitation,LoginForm,costumerprofileform
from django.contrib.auth.forms import UserCreationForm,PasswordChangeForm,PasswordResetForm
from .models import customer, Product, cart
from django.contrib import messages
from django.utils.translation import gettext, gettext_lazy as _
from django.contrib.auth.models import User
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth import logout
# show products home page
class Productview(View):
 def get(self, request):
  Top_wear=Product.objects.filter(category='TW')
  Botom_wear=Product.objects.filter(category='BW')
  Mobile=Product.objects.filter(category='M')
  Laptop=Product.objects.filter(category='L')
  other=Product.objects.filter(category='ot')
  return render(request, 'app/home.html',{'topwears':Top_wear,'botomwears':Botom_wear,'mobiles':Mobile,'Laptops':Laptop,'other':other})
# product_detailing
class product_detail(View):
 def get(self, request, pk):
  product=Product.objects.get(pk=pk)
  return render(request, 'app/productdetail.html',{'product':product})
# cart product  in cart buccket 
def add_to_cart(request):
  # if request.user.is_authtenticated:
  user=request.user
  product_id=request.GET.get('prod_id')
  product=Product.objects.get(id=product_id) 
  cart(user=user, product=product).save()
  return redirect('/cart')
#show cart product
def show_cart(request):
#  if request.user.is_authtenticated:
  user=request.user
  Cart=cart.objects.filter(user=user)
  amount=0.0
  shepping_amount=70
  totalamount=0
  cart_product=[p for p in cart.objects.all() if p.user==user]
  if cart_product:
   for p in cart_product:
    tempamout=(p.quantity * p.product.selling_price)
    amount+=tempamout
    totalamount=amount+shepping_amount
    return render(request,'app/addtocart.html',{'cart':Cart,'user':user,'amount':amount,'totalamount':totalamount})
  else:
   return render(request,'app/addtocart.html',{'cart':Cart,'user':user,'amount':amount,'totalamount':totalamount})
# pluse cart item
def pluscart(request):
 if request.method=='GET':
  prod_id=request.GET['prod_id']
  print(prod_id)
  c=cart.objects.get(Q(product=prod_id) & Q(user=request.user))
  c.quantity+=1
  c.save()
  amount=0.0
  shepping_amount=70
  cart_product=[p for p in cart.objects.all() if p.user==request.user]
  if cart_product:
   for p in cart_product:
    tempamount=(p.quantity * p.product.selling_price)
    amount+=tempamount
    totalamount=amount+shepping_amount
   data={
    'quantity':p.quantity,
    'amount':amount,
    'totalamount':totalamount,
    }  
  return JsonResponse(data)
# minus cart item
def minuscart(request):
 if request.method=='GET':
  prod_id=request.GET['prod_id']
  print(prod_id)
  c =cart.objects.get(Q(product=prod_id) & Q(user=request.user))
  c.quantity-=1
  c.save()
  amount=0.0
  shepping_amount=70
  cart_product=[p for p in cart.objects.all() if p.user==request.user]
  if cart_product:
   for p in cart_product:
    tempamount=(p.quantity * p.product.selling_price)
    amount+=tempamount  
    totalamount =amount +shepping_amount
   data={
    'quantity':c.quantity,
    'amount':amount,
    'totalamount':totalamount,
     }  
  return JsonResponse(data)
# remove product from cart
def removecart(request):
 if request.method=='GET':
  prod_id=request.GET['prod_id']
  print(prod_id)
  c=cart.objects.get(Q(product=prod_id) & Q(user=request.user))
  c.delete()
  amount=0.0
  shepping_amount=70
  cart_product=[p for p in cart.objects.all() if p.user==request.user]
  if cart_product:
   for p in cart_product:
    tempamount=(c.quantity * p.product.selling_price)
    amount+=tempamount
  
   data={
    'amount':amount,
    'totalamount':amount + shepping_amount,
     }  
   return JsonResponse(data)
 
def buy_now(request):
 return render(request, 'app/buynow.html')
# coustumer profile or adding costumer addresh
class costomerprofile(View):
 def get(self, request):
  form=costumerprofileform()
  return render(request, 'app/profile.html',{'form':form,'active':'btn-primary'})
 def post(self, request):
  form=costumerprofileform(request.POST)
  if form.is_valid():
   user=request.user
   name=form.cleaned_data['name']
   locality=form.cleaned_data['locality']
   city=form.cleaned_data['city']
   zipcode=form.cleaned_data['zipcode']
   state=form.cleaned_data['state']
   data=customer(user=user, name=name, city=city, state=state ,zipcode=zipcode, locality=locality)
   data.save()
   messages.success(request,'your profile update successfully')
  return render(request,'app/profile.html',{'form':form})


def address(request):
 address=customer.objects.filter(user=request.user)
 return render(request, 'app/address.html',{'address':address,'active':'btn btn-primary'})

def orders(request):
 return render(request, 'app/orders.html')

def change_password(request):
 return render(request, 'app/changepassword.html')
#
def mobile(request,data=None):
 if data == None:
  mobiles=Product.objects.filter(category='M')
 elif data=='iphone' or data=='redmi' or data=='motorola':
  mobiles=Product.objects.filter(category='M').filter(brand=data)
 elif data=='below':
  mobiles=Product.objects.filter(category='M').filter(selling_price__lt=30000)
 elif data=='above':
  mobiles=Product.objects.filter(category='M').filter(selling_price__gt=30000)
 return render(request, 'app/mobile.html',{'mobiles':mobiles})

#registation
class customerregistration(View):
 def get(self,request):
  form=Customer_regitation()
  return render(request, 'app/customerregistration.html',{'form':form})
 def post(self, request):
  form=Customer_regitation(request.POST)
  if form.is_valid():
   messages.success(request,'congratualitions regstration succesfully')
   form.save()
  return render(request, 'app/customerregistration.html',{'form':form})
  
  
# placed  cart order 
def checkout(request):
 user=request.user
 add=customer.objects.filter(user=user)
 cart_items=cart.objects.filter(user=user)
 amount=0
 shepping_amount=70.0
 totalamount=0.0
 cart_product=[p for p in cart.objects.all() if p.user==request.user]
 if cart_product:
  for p in cart_product:
   tempamount=(p.quantity * p.product.selling_price)
   amount+=tempamount
  totalamount=amount+shepping_amount
 return render(request, 'app/checkout.html',{'add':add,'totalamount':totalamount,'cart_items':cart_items})
#logout user from 
def logout_user(request):
  # if request.user_is_autheticated:
   user=request.user
   logout(request)
   return HttpResponseRedirect('/login/')